<?php

$categoryConfig[3]['id'] =              3;
$categoryConfig[3]['name'] =            'dfgfg';
$categoryConfig[3]['public'] =          true;
$categoryConfig[3]['createdelete'] =    false;
$categoryConfig[3]['thumbnail'] =       false;
$categoryConfig[3]['plugins'] =         false;
$categoryConfig[3]['showtags'] =        false;
$categoryConfig[3]['showpagedate'] =    false;
$categoryConfig[3]['sortbypagedate'] =  false;
$categoryConfig[3]['sortascending'] =   false;

$categoryConfig[3]['styleFile'] =       '';
$categoryConfig[3]['styleId'] =         'conte_dsfnt';
$categoryConfig[3]['styleClass'] =      '';

$categoryConfig[3]['thumbWidth'] =      '';
$categoryConfig[3]['thumbHeight'] =     '';
$categoryConfig[3]['thumbRatio'] =      '';


$categoryConfig[1]['id'] =              1;
$categoryConfig[1]['name'] =            'Test';
$categoryConfig[1]['public'] =          true;
$categoryConfig[1]['createdelete'] =    true;
$categoryConfig[1]['thumbnail'] =       false;
$categoryConfig[1]['plugins'] =         true;
$categoryConfig[1]['showtags'] =        false;
$categoryConfig[1]['showpagedate'] =    false;
$categoryConfig[1]['sortbypagedate'] =  false;
$categoryConfig[1]['sortascending'] =   false;

$categoryConfig[1]['styleFile'] =       '';
$categoryConfig[1]['styleId'] =         '';
$categoryConfig[1]['styleClass'] =      '';

$categoryConfig[1]['thumbWidth'] =      '';
$categoryConfig[1]['thumbHeight'] =     '';
$categoryConfig[1]['thumbRatio'] =      '';


$categoryConfig[2]['id'] =              2;
$categoryConfig[2]['name'] =            'News';
$categoryConfig[2]['public'] =          true;
$categoryConfig[2]['createdelete'] =    false;
$categoryConfig[2]['thumbnail'] =       false;
$categoryConfig[2]['plugins'] =         false;
$categoryConfig[2]['showtags'] =        false;
$categoryConfig[2]['showpagedate'] =    true;
$categoryConfig[2]['sortbypagedate'] =  true;
$categoryConfig[2]['sortascending'] =   false;

$categoryConfig[2]['styleFile'] =       '';
$categoryConfig[2]['styleId'] =         '';
$categoryConfig[2]['styleClass'] =      '';

$categoryConfig[2]['thumbWidth'] =      '';
$categoryConfig[2]['thumbHeight'] =     '';
$categoryConfig[2]['thumbRatio'] =      '';


return $categoryConfig;
?>