<?php

$statisticConfig['number']['mostVisitedPages']        = '20';
$statisticConfig['number']['longestVisitedPages']     = '20';
$statisticConfig['number']['lastEditedPages']         = '40';

$statisticConfig['number']['refererLog']    = '500';
$statisticConfig['number']['taskLog']       = '200';

return $statisticConfig;
?>