<?php

$pluginsConfig['contactform']['active'] = false;
$pluginsConfig['testplugin']['active'] = false;
$pluginsConfig['imageGallery']['active'] = true;
$pluginsConfig['contactForm']['active'] = true;

return $pluginsConfig;
?>