<?php

$websiteConfig['title']          = 'feindura Flat File CMS';
$websiteConfig['publisher']      = 'Fabian Vogelsteller';
$websiteConfig['copyright']      = 'Fabian Vogels&amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;#039;teller';
$websiteConfig['keywords']       = 'content,management,system,cms,flat,files,open,source,free,software,GPL';
$websiteConfig['description']    = 'zuh&amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;#039;&amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;#039;&amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;#039;&amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;#039;';

$websiteConfig['startPage']      = '1';

return $websiteConfig;
?>