<?php

$pageContent['id'] =                 1;
$pageContent['category'] =           0;
$pageContent['public'] =             true;
$pageContent['sortorder'] =          3;

$pageContent['lastsavedate'] =       '1287431111';
$pageContent['lastsaveauthor'] =     'frozeman';

$pageContent['title'] =              'Welcome';
$pageContent['description'] =        '';

$pageContent['pagedate']['before'] = '';
$pageContent['pagedate']['date'] =   '';
$pageContent['pagedate']['after'] =  '';
$pageContent['tags'] =               '';

$pageContent['thumbnail'] =          '';
$pageContent['styleFile'] =          '';
$pageContent['styleId'] =            '';
$pageContent['styleClass'] =         '';

$pageContent['log_visitorcount'] =   '';
$pageContent['log_visitTime_min'] =  '';
$pageContent['log_visitTime_max'] =  '';
$pageContent['log_firstVisit'] =     '';
$pageContent['log_lastVisit'] =      '';
$pageContent['log_searchwords'] =    '';

$pageContent['content'] = 
'Test text';

return $pageContent;
?>