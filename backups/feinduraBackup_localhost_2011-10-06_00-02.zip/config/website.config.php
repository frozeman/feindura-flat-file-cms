<?php

$websiteConfig['title']          = '漢字編碼方法';
$websiteConfig['publisher']      = '漢字編碼方法';
$websiteConfig['copyright']      = '漢字編碼方法';
$websiteConfig['keywords']       = '漢字編碼方法,漢字編碼方法,漢字編碼方法';
$websiteConfig['description']    = '漢字編碼方法';

$websiteConfig['startPage']      = 0;

return $websiteConfig;
?>