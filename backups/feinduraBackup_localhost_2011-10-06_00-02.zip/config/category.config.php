<?php

$categoryConfig[1]['id'] =              1;
$categoryConfig[1]['name'] =            'testkate';
$categoryConfig[1]['public'] =          true;
$categoryConfig[1]['createDelete'] =    true;
$categoryConfig[1]['thumbnail'] =       false;
$categoryConfig[1]['plugins'] =         false;
$categoryConfig[1]['showTags'] =        false;
$categoryConfig[1]['showPageDate'] =    true;
$categoryConfig[1]['sortByPageDate'] =  true;
$categoryConfig[1]['sortAscending'] =   false;

$categoryConfig[1]['styleFile'] =       '';
$categoryConfig[1]['styleId'] =         '';
$categoryConfig[1]['styleClass'] =      '';

$categoryConfig[1]['thumbWidth'] =      '';
$categoryConfig[1]['thumbHeight'] =     '';
$categoryConfig[1]['thumbRatio'] =      '';


return $categoryConfig;
?>