<?php

$pluginsConfig['imageGallery']['active'] =     true;
$pluginsConfig['contactForm']['active'] =     true;

return $pluginsConfig;
?>