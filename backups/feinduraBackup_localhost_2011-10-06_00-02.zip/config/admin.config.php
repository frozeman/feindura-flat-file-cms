<?php

$adminConfig['url'] =              'http://localhost';
$adminConfig['basePath'] =         '/_feindura/';
$adminConfig['realBasePath'] =     '/Users/frozeman/Development/Server/_feindura/';
$adminConfig['websitePath'] =      '/';
$adminConfig['uploadPath'] =       '/_feindura/_upload/';
$adminConfig['websiteFilesPath'] = '/_feindura/addonss/';
$adminConfig['stylesheetPath'] =   '';

$adminConfig['permissions'] =      0755;
$adminConfig['timeZone'] =         'Europe/Berlin';
$adminConfig['dateFormat'] =       'eu';
$adminConfig['speakingUrl'] =      false;

$adminConfig['varName']['page'] =     'page';
$adminConfig['varName']['category'] = 'category';
$adminConfig['varName']['modul'] =    'modul';

$adminConfig['user']['frontendEditing'] =  true;
$adminConfig['user']['fileManager'] =      true;
$adminConfig['user']['editWebsiteFiles'] = true;
$adminConfig['user']['editStyleSheets'] =  true;
$adminConfig['user']['info'] =             '';

$adminConfig['setStartPage'] =          false;
$adminConfig['pages']['createDelete'] = true;
$adminConfig['pages']['thumbnails'] =   true;
$adminConfig['pages']['plugins'] =      '1';
$adminConfig['pages']['showTags'] =     true;
$adminConfig['pages']['showPageDate'] = false;
$adminConfig['pages']['feeds'] =        false;

$adminConfig['pages']['sorting'] =      'manually';
$adminConfig['pages']['sortReverse'] =  false;

$adminConfig['editor']['htmlLawed'] =  false;
$adminConfig['editor']['safeHtml'] =   false;
$adminConfig['editor']['enterMode'] =  'p';
$adminConfig['editor']['styleFile'] =  'a:1:{i:0;s:17:"/style/layout.css";}';
$adminConfig['editor']['styleId'] =    '';
$adminConfig['editor']['styleClass'] = '';

$adminConfig['pageThumbnail']['width'] =  '100';
$adminConfig['pageThumbnail']['height'] = '0';
$adminConfig['pageThumbnail']['ratio'] =  'x';
$adminConfig['pageThumbnail']['path'] =   'thumbnails/';

return $adminConfig;
?>