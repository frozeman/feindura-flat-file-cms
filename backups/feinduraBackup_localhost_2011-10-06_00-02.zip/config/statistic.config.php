<?php

$statisticConfig['number']['mostVisitedPages']        = 11;
$statisticConfig['number']['longestVisitedPages']     = 13;
$statisticConfig['number']['lastVisitedPages']        = 12;
$statisticConfig['number']['lastEditedPages']         = 14;

$statisticConfig['number']['refererLog']    = 100;
$statisticConfig['number']['taskLog']       = 50;

return $statisticConfig;
?>