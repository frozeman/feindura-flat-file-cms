<?php

$pageStatistics['id'] =             7;
$pageStatistics['visitorCount'] =   4;
$pageStatistics['firstVisit'] =     1303835410;
$pageStatistics['lastVisit'] =      1304451740;
$pageStatistics['visitTimeMin'] =  'a:2:{i:0;i:21;i:1;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:1:{i:0;i:40;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>