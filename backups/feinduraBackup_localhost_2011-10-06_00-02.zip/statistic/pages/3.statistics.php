<?php

$pageStatistics['id'] =             3;
$pageStatistics['visitorCount'] =   121245221541;
$pageStatistics['firstVisit'] =     1303504054;
$pageStatistics['lastVisit'] =      1307203658;
$pageStatistics['visitTimeMin'] =  'a:9:{i:0;i:1340;i:1;i:719;i:2;i:158;i:3;i:149;i:4;i:23;i:5;i:18;i:6;i:8;i:7;i:6;i:8;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:1:{i:0;i:1483;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>