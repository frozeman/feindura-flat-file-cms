<?php

$pageStatistics['id'] =             22;
$pageStatistics['visitorCount'] =   2;
$pageStatistics['firstVisit'] =     1303933065;
$pageStatistics['lastVisit'] =      1304450284;
$pageStatistics['visitTimeMin'] =  '';
$pageStatistics['visitTimeMax'] =  '';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>