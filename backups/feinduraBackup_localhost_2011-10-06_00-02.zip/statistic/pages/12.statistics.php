<?php

$pageStatistics['id'] =             12;
$pageStatistics['visitorCount'] =   3;
$pageStatistics['firstVisit'] =     1303797870;
$pageStatistics['lastVisit'] =      1306534502;
$pageStatistics['visitTimeMin'] =  'a:1:{i:0;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:1:{i:0;i:6;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>