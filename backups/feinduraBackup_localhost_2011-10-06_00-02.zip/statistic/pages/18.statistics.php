<?php

$pageStatistics['id'] =             18;
$pageStatistics['visitorCount'] =   1;
$pageStatistics['firstVisit'] =     1303765686;
$pageStatistics['lastVisit'] =      1303765949;
$pageStatistics['visitTimeMin'] =  'a:5:{i:0;i:62;i:1;i:35;i:2;i:31;i:3;i:7;i:4;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:1:{i:0;i:94;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>