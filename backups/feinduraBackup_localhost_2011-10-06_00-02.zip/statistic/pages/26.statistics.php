<?php

$pageStatistics['id'] =             26;
$pageStatistics['visitorCount'] =   6;
$pageStatistics['firstVisit'] =     1303820014;
$pageStatistics['lastVisit'] =      1306534217;
$pageStatistics['visitTimeMin'] =  'a:1:{i:0;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:2:{i:0;i:23;i:1;i:9;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>