<?php

$pageStatistics['id'] =             10;
$pageStatistics['visitorCount'] =   1;
$pageStatistics['firstVisit'] =     1303818736;
$pageStatistics['lastVisit'] =      1303818736;
$pageStatistics['visitTimeMin'] =  'a:1:{i:0;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:1:{i:0;i:24;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>