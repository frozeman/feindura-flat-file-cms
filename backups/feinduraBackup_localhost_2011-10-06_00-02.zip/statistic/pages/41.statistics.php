<?php

$pageStatistics['id'] =             41;
$pageStatistics['visitorCount'] =   2;
$pageStatistics['firstVisit'] =     1303937666;
$pageStatistics['lastVisit'] =      1307203656;
$pageStatistics['visitTimeMin'] =  'a:3:{i:0;i:89;i:1;i:26;i:2;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:1:{i:0;i:598;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>