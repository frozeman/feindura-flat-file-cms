<?php

$pageStatistics['id'] =             14;
$pageStatistics['visitorCount'] =   2;
$pageStatistics['firstVisit'] =     1303840831;
$pageStatistics['lastVisit'] =      1306534173;
$pageStatistics['visitTimeMin'] =  'a:1:{i:0;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:1:{i:0;i:4206;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>