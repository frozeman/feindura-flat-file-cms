<?php

$pageStatistics['id'] =             19;
$pageStatistics['visitorCount'] =   4;
$pageStatistics['firstVisit'] =     1303768794;
$pageStatistics['lastVisit'] =      1303929017;
$pageStatistics['visitTimeMin'] =  'a:3:{i:0;i:16;i:1;i:7;i:2;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:2:{i:0;i:132;i:1;i:18;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>