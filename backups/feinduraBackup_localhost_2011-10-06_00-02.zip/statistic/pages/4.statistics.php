<?php

$pageStatistics['id'] =             4;
$pageStatistics['visitorCount'] =   0;
$pageStatistics['firstVisit'] =     0;
$pageStatistics['lastVisit'] =      0;
$pageStatistics['visitTimeMin'] =  'a:1:{i:0;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:1:{i:0;i:719;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>