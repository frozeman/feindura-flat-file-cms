<?php

$pageStatistics['id'] =             6;
$pageStatistics['visitorCount'] =   0;
$pageStatistics['firstVisit'] =     0;
$pageStatistics['lastVisit'] =      0;
$pageStatistics['visitTimeMin'] =  'a:2:{i:0;i:23;i:1;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:1:{i:0;i:149;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>