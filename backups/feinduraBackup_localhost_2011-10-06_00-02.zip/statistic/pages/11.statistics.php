<?php

$pageStatistics['id'] =             11;
$pageStatistics['visitorCount'] =   5;
$pageStatistics['firstVisit'] =     1303892998;
$pageStatistics['lastVisit'] =      1306533938;
$pageStatistics['visitTimeMin'] =  'a:3:{i:0;i:19;i:1;i:6;i:2;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:1:{i:0;i:45;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>