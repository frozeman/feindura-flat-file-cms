<?php

$pageStatistics['id'] =             20;
$pageStatistics['visitorCount'] =   1;
$pageStatistics['firstVisit'] =     1303768960;
$pageStatistics['lastVisit'] =      1303768960;
$pageStatistics['visitTimeMin'] =  '';
$pageStatistics['visitTimeMax'] =  '';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>