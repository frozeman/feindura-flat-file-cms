<?php

$pageStatistics['id'] =             27;
$pageStatistics['visitorCount'] =   2;
$pageStatistics['firstVisit'] =     1304451672;
$pageStatistics['lastVisit'] =      1306534182;
$pageStatistics['visitTimeMin'] =  '';
$pageStatistics['visitTimeMax'] =  '';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>