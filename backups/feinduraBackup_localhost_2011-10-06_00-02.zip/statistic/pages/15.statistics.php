<?php

$pageStatistics['id'] =             15;
$pageStatistics['visitorCount'] =   1;
$pageStatistics['firstVisit'] =     1303772583;
$pageStatistics['lastVisit'] =      1303772583;
$pageStatistics['visitTimeMin'] =  '';
$pageStatistics['visitTimeMax'] =  '';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>