<?php

$pageStatistics['id'] =             13;
$pageStatistics['visitorCount'] =   2;
$pageStatistics['firstVisit'] =     1303933180;
$pageStatistics['lastVisit'] =      1304451750;
$pageStatistics['visitTimeMin'] =  'a:1:{i:0;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:2:{i:0;i:78203;i:1;i:34;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>