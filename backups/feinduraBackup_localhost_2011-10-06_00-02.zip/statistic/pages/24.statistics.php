<?php

$pageStatistics['id'] =             24;
$pageStatistics['visitorCount'] =   6;
$pageStatistics['firstVisit'] =     1303768746;
$pageStatistics['lastVisit'] =      1303932122;
$pageStatistics['visitTimeMin'] =  'a:5:{i:0;i:45;i:1;i:36;i:2;i:28;i:3;i:9;i:4;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:3:{i:0;i:674;i:1;i:65;i:2;i:44;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>