<?php

$pageStatistics['id'] =             23;
$pageStatistics['visitorCount'] =   1;
$pageStatistics['firstVisit'] =     1306533957;
$pageStatistics['lastVisit'] =      1306533957;
$pageStatistics['visitTimeMin'] =  '';
$pageStatistics['visitTimeMax'] =  '';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>