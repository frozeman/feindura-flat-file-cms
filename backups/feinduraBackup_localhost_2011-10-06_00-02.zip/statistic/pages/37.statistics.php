<?php

$pageStatistics['id'] =             37;
$pageStatistics['visitorCount'] =   1;
$pageStatistics['firstVisit'] =     1303933067;
$pageStatistics['lastVisit'] =      1303933067;
$pageStatistics['visitTimeMin'] =  'a:1:{i:0;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:1:{i:0;i:61;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>