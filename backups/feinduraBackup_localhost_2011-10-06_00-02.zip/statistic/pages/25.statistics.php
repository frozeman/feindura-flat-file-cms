<?php

$pageStatistics['id'] =             25;
$pageStatistics['visitorCount'] =   2;
$pageStatistics['firstVisit'] =     1303933063;
$pageStatistics['lastVisit'] =      1306533906;
$pageStatistics['visitTimeMin'] =  '';
$pageStatistics['visitTimeMax'] =  '';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>