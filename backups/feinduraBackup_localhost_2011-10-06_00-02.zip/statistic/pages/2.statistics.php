<?php

$pageStatistics['id'] =             2;
$pageStatistics['visitorCount'] =   2;
$pageStatistics['firstVisit'] =     1303838885;
$pageStatistics['lastVisit'] =      1303936281;
$pageStatistics['visitTimeMin'] =  'a:1:{i:0;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:2:{i:0;i:1385;i:1;i:226;}';
$pageStatistics['searchWords'] =    'a:2:{i:0;a:2:{s:4:"data";s:5:"magix";s:6:"number";i:1;}i:1;a:2:{s:4:"data";s:13:"gutscheincode";s:6:"number";i:1;}}';

return $pageStatistics;
?>