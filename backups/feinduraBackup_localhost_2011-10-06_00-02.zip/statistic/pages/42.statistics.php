<?php

$pageStatistics['id'] =             42;
$pageStatistics['visitorCount'] =   6;
$pageStatistics['firstVisit'] =     1306578956;
$pageStatistics['lastVisit'] =      1307310063;
$pageStatistics['visitTimeMin'] =   'a:1:{i:0;i:0;}';
$pageStatistics['visitTimeMax'] =   'a:2:{i:0;i:778;i:1;i:63;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>