<?php

$pageStatistics['id'] =             40;
$pageStatistics['visitorCount'] =   0;
$pageStatistics['firstVisit'] =     0;
$pageStatistics['lastVisit'] =      0;
$pageStatistics['visitTimeMin'] =  '';
$pageStatistics['visitTimeMax'] =  '';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>