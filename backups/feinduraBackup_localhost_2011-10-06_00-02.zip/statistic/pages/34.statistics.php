<?php

$pageStatistics['id'] =             34;
$pageStatistics['visitorCount'] =   3;
$pageStatistics['firstVisit'] =     1303915671;
$pageStatistics['lastVisit'] =      1306533962;
$pageStatistics['visitTimeMin'] =  'a:1:{i:0;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:2:{i:0;i:211;i:1;i:10;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>