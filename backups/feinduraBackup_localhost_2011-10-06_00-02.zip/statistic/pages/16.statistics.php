<?php

$pageStatistics['id'] =             16;
$pageStatistics['visitorCount'] =   1;
$pageStatistics['firstVisit'] =     1306533896;
$pageStatistics['lastVisit'] =      1306533896;
$pageStatistics['visitTimeMin'] =  'a:1:{i:0;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:1:{i:0;i:10;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>