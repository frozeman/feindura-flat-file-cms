<?php

$pageStatistics['id'] =             28;
$pageStatistics['visitorCount'] =   1;
$pageStatistics['firstVisit'] =     1303768087;
$pageStatistics['lastVisit'] =      1303768087;
$pageStatistics['visitTimeMin'] =  'a:1:{i:0;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:1:{i:0;i:7;}';
$pageStatistics['searchWords'] =    '';

return $pageStatistics;
?>