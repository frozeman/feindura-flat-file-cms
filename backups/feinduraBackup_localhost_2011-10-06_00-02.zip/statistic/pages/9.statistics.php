<?php

$pageStatistics['id'] =             9;
$pageStatistics['visitorCount'] =   3;
$pageStatistics['firstVisit'] =     1303797844;
$pageStatistics['lastVisit'] =      1303913289;
$pageStatistics['visitTimeMin'] =  'a:1:{i:0;i:0;}';
$pageStatistics['visitTimeMax'] =  'a:2:{i:0;i:917;i:1;i:26;}';
$pageStatistics['searchWords'] =    'a:3:{i:0;a:2:{s:4:"data";s:13:"gutscheincode";s:6:"number";i:2;}i:1;a:2:{s:4:"data";s:5:"magix";s:6:"number";i:2;}i:2;a:2:{s:4:"data";s:6:"online";s:6:"number";i:2;}}';

return $pageStatistics;
?>