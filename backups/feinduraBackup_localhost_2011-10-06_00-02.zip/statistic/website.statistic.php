<?php

$websiteStatistic['userVisitCount'] =    12;
$websiteStatistic['spiderVisitCount'] =  0;

$websiteStatistic['firstVisit'] =        1299436510;
$websiteStatistic['lastVisit'] =         1300174743;

$websiteStatistic['browser'] =           'a:4:{i:0;a:2:{s:4:"data";s:6:"chrome";s:6:"number";i:5;}i:1;a:2:{s:4:"data";s:5:"opera";s:6:"number";i:3;}i:2;a:2:{s:4:"data";s:7:"firefox";s:6:"number";i:1;}i:3;a:2:{s:4:"data";s:17:"internet explorer";s:6:"number";i:1;}}';

return $websiteStatistic;
?>