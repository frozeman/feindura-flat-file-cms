<?php

$pageContent['id'] =                 1;
$pageContent['category'] =           0;
$pageContent['sortOrder'] =          1;
$pageContent['public'] =             false;

$pageContent['lastSaveDate'] =       1317849405;
$pageContent['lastSaveAuthor'] =     '';

$pageContent['title'] =              'test';
$pageContent['description'] =        '';

$pageContent['pageDate']['before'] = '';
$pageContent['pageDate']['date'] =   0;
$pageContent['pageDate']['after'] =  '';
$pageContent['tags'] =               '';

$pageContent['thumbnail'] =          '';
$pageContent['styleFile'] =          '';
$pageContent['styleId'] =            '';
$pageContent['styleClass'] =         '';

$pageContent['content'] = '';

return $pageContent;
?>