<?php

$websiteConfig['title']          = 'feindura Flat File CMS';
$websiteConfig['publisher']      = 'Fabian Vogelsteller';
$websiteConfig['copyright']      = 'Fabian Vogels&#039;teller';
$websiteConfig['keywords']       = 'content,management,system,cms,flat,files,open,source,free,software,GPL';
$websiteConfig['description']    = 'zuh&#039;&#039;&#039;&#039;';

$websiteConfig['startPage']      = '13';

return $websiteConfig;
?>