<?php

$websiteStatistic['userVisitCount'] =    '29';
$websiteStatistic['spiderVisitCount'] =  '0';

$websiteStatistic['firstVisit'] =        '1285265796';
$websiteStatistic['lastVisit'] =         '1288302117';

$websiteStatistic['browser'] =      'a:6:{i:0;a:2:{s:4:"data";s:7:"firefox";s:6:"number";i:11;}i:1;a:2:{s:4:"data";s:7:"unknown";s:6:"number";i:6;}i:2;a:2:{s:4:"data";s:6:"chrome";s:6:"number";i:6;}i:3;a:2:{s:4:"data";s:5:"opera";s:6:"number";i:3;}i:4;a:2:{s:4:"data";s:6:"safari";s:6:"number";i:2;}i:5;a:2:{s:4:"data";s:17:"internet explorer";s:6:"number";i:1;}}';

return $websiteStatistic;
?>