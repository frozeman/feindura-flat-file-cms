<?php

$pageContent['id'] =                 1;
$pageContent['category'] =           0;
$pageContent['public'] =             true;
$pageContent['sortorder'] =          3;

$pageContent['lastsavedate'] =       '1287431111';
$pageContent['lastsaveauthor'] =     'frozeman';

$pageContent['title'] =              'Welcome';
$pageContent['description'] =        '';

$pageContent['pagedate']['before'] = '';
$pageContent['pagedate']['date'] =   '';
$pageContent['pagedate']['after'] =  '';
$pageContent['tags'] =               '';

$pageContent['thumbnail'] =          '';
$pageContent['styleFile'] =          '';
$pageContent['styleId'] =            '';
$pageContent['styleClass'] =         '';

$pageContent['log_visitorcount'] =   '';
$pageContent['log_visitTime_min'] =  '';
$pageContent['log_visitTime_max'] =  '';
$pageContent['log_firstVisit'] =     '';
$pageContent['log_lastVisit'] =      '';
$pageContent['log_searchwords'] =    '';

$pageContent['content'] = 
'<blockquote>
	<span style="font-size: 18px;"><span class="feindura"><em>fein</em>dura</span> 1.0 <span style="font-size: 14px;"><em>release candsfdsf</em></span></span></blockquote>
<blockquote>
	<span style="font-size: 18px;"><span style="font-size: 14px;"><em>ffsdfdfdidate</em></span> is now available for <a href="?site=download">download</a>,<br />
	the final 1.0 will be released soon...</span></blockquote>
<p>
	<span class="feindura"><em>fein</em>dura</span> is a flat file based Content Management System written in PHP, which doesn&#39;t need a database. just create your Layout, <a href="?site=gettingstarted">integrate <span class="feindura"><em>fein</em>dura</span> in your website</a> and upload it on your server and you&#39;re finished.</p>
<p>
	This CMS is intended to help you to&nbsp;simple fill your designs with content, so that you can focus entirely on the interesting part of your work. <span class="feindura"><em>fein</em>dura</span> is deliberately designed without a template system, all you need is some basic knowledge in PHP and our <a href="?site=examples">examples</a> or the <a href="/api/%5BImplementation%5D/feindura.html">API reference</a>!</p>
<p>
	fdgdfgdfg</p>
<h2>
	Requirements</h2>
<ul>
	<li>
		<strong>Apache Server</strong> (required for the .htaccess login and <strong>mod_rewrite module</strong> for&nbsp;Speaking URLs)</li>
	<li>
		<strong>PHP &gt; 4.3.0 </strong>(SafeMode OFF) (<strong>PHP 5</strong>&nbsp;required for the File Manager)</li>
	<li>
		<strong>Javascript</strong></li>
</ul>
';

return $pageContent;
?>